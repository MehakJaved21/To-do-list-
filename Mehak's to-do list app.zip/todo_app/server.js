const express = require('express');
const bodyParser = require('body-parser');
const db = require('./database');

const app = express();
const PORT = 3000;

app.use(bodyParser.json());
app.use(express.static('public'));

// Create a new task
app.post('/api/tasks', (req, res) => {
    const { text, priority, due_date } = req.body;
    db.run(`INSERT INTO tasks (text, priority, due_date) VALUES (?, ?, ?)`, [text, priority, due_date], function (err) {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.json({ id: this.lastID, text, completed: 0, priority, due_date });
    });
});

// Get all tasks
app.get('/api/tasks', (req, res) => {
    db.all(`SELECT * FROM tasks`, [], (err, rows) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.json(rows);
    });
});

// Update a task
app.put('/api/tasks/:id', (req, res) => {
    const { id } = req.params;
    const { text, completed, priority, due_date } = req.body;
    db.run(`UPDATE tasks SET text = ?, completed = ?, priority = ?, due_date = ? WHERE id = ?`, [text, completed, priority, due_date, id], function (err) {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.json({ id, text, completed, priority, due_date });
    });
});

// Delete a task
app.delete('/api/tasks/:id', (req, res) => {
    const { id } = req.params;
    db.run(`DELETE FROM tasks WHERE id = ?`, [id], function (err) {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.json({ message: 'Task deleted' });
    });
});

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
