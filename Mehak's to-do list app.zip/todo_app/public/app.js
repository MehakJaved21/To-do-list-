document.addEventListener('DOMContentLoaded', () => {
    const taskForm = document.getElementById('task-form');
    const taskInput = document.getElementById('task-input');
    const taskList = document.getElementById('task-list');
    const filterButtons = document.querySelectorAll('.filters button');

    let tasks = [];
    let currentFilter = 'all';

    fetch('/api/tasks')
        .then(response => response.json())
        .then(data => {
            tasks = data;
            renderTasks();
        });

    taskForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const taskText = taskInput.value.trim();
        if (taskText) {
            const newTask = {
                text: taskText,
                priority: 0,
                due_date: null
            };
            fetch('/api/tasks', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(newTask)
            })
                .then(response => response.json())
                .then(task => {
                    tasks.push(task);
                    taskInput.value = '';
                    renderTasks();
                });
        }
    });

    taskList.addEventListener('click', (e) => {
        const taskId = e.target.parentElement.dataset.id;
        if (e.target.classList.contains('delete')) {
            fetch(`/api/tasks/${taskId}`, {
                method: 'DELETE'
            })
                .then(response => response.json())
                .then(() => {
                    tasks = tasks.filter(task => task.id !== parseInt(taskId));
                    renderTasks();
                });
        } else if (e.target.classList.contains('complete')) {
            const task = tasks.find(task => task.id === parseInt(taskId));
            task.completed = !task.completed;
            fetch(`/api/tasks/${taskId}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(task)
            })
                .then(response => response.json())
                .then(updatedTask => {
                    const index = tasks.findIndex(task => task.id === parseInt(taskId));
                    tasks[index] = updatedTask;
                    renderTasks();
                });
        } else if (e.target.classList.contains('edit')) {
            const task = tasks.find(task => task.id === parseInt(taskId));
            const editInput = document.createElement('input');
            editInput.type = 'text';
            editInput.classList.add('edit-input');
            editInput.value = task.text;
            e.target.parentElement.replaceChild(editInput, e.target);
            editInput.addEventListener('blur', () => {
                task.text = editInput.value;
                fetch(`/api/tasks/${taskId}`, {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(task)
                })
                    .then(response => response.json())
                    .then(updatedTask => {
                        const index = tasks.findIndex(task => task.id === parseInt(taskId));
                        tasks[index] = updatedTask;
                        renderTasks();
                    });
            });
            editInput.focus();
        }
    });

    filterButtons.forEach(button => {
        button.addEventListener('click', () => {
            currentFilter = button.id.split('-')[0];
            renderTasks();
        });
    });

    function renderTasks() {
        taskList.innerHTML = ''; // Clear previous tasks
    
        const filteredTasks = tasks.filter(task => {
            if (currentFilter === 'all') return true;
            if (currentFilter === 'active') return !task.completed;
            if (currentFilter === 'completed') return task.completed;
        });
    
        filteredTasks.forEach(task => {
            const taskItem = document.createElement('li');
            taskItem.dataset.id = task.id;
    
            // Ensure task.completed is a Boolean (true or false)
            const isCompleted = !!task.completed;
    
            // Add 'completed' class if task is completed
            if (isCompleted) {
                taskItem.classList.add('completed');
            }
    
            taskItem.innerHTML = `
                <span>${task.text}</span>
                <button class="edit">Edit</button>
                <button class="complete">${isCompleted ? 'Undo' : 'Complete'}</button>
                <button class="delete">Delete</button>
            `;
    
            taskList.appendChild(taskItem); // Append task item to taskList
        });
    }
    
    
});
