const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('./todo.db'); // Specify a file path for the database

db.serialize(() => {
    db.run(`CREATE TABLE IF NOT EXISTS tasks (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        text TEXT NOT NULL,
        completed INTEGER NOT NULL DEFAULT 0,
        priority INTEGER NOT NULL DEFAULT 0,
        due_date TEXT
    )`);

});

module.exports = db;
